
File locations:
	START PAGE: 	INDEX.HTM
	DICOM  :	DICOM images
	IHE_PDI:	Web content
	REPORTS:	Reports (Optional)
	KEY_IMAGES:     Key Images (Optional)



		


